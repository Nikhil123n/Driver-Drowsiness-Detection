#ifndef DLIB_REVISION_H
// Version:  19.23
// Date:     Mon Jan 24 22:10:28 EST 2022
// Git Changeset ID:  074ab8bdbadbee1afb95653c3ce46867ed32dfa1
#define DLIB_MAJOR_VERSION  19
#define DLIB_MINOR_VERSION  23
#define DLIB_PATCH_VERSION  0
#endif
